const appointmentsElement = document.getElementById('appointments');
const appointmentForm = document.getElementById('appointmentForm');

let appointments = []; // Load appointments from JSON (explained later)

function displayAppointments() {
    appointmentsElement.innerHTML = '';}
    function displayAppointmentDetails(event) {
        event.preventDefault(); // Prevent the form from submitting
    
        // Retrieve form data
        var date = document.getElementById("date").value;
        var time = document.getElementById("time").value;
        var subject = document.getElementById("subject").value;
        var provider = document.getElementById("provider").value;
        var location = document.getElementById("location").value;
    
        // Update appointment details
        document.getElementById("Date").textContent = date;
        document.getElementById("Time").textContent = time;
        document.getElementById("Subject").textContent = subject;
        document.getElementById("Provider").textContent = provider;
        document.getElementById("Location").textContent = location;
    
        // Display appointment details section
        document.getElementById("appoinmentDetails").style.display = "block";
    }
    